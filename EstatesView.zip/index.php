<?php
// index.php

// Redirect to login page by default
header("Location: view/home.php");
exit();
